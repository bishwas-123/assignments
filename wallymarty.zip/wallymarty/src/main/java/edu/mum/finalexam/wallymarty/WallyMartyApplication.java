package edu.mum.finalexam.wallymarty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WallyMartyApplication {

    public static void main(String[] args) {
        SpringApplication.run(WallyMartyApplication.class, args);
    }

}
